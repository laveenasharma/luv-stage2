var gameState,bg;
var platform,platform1,platform2;
var doorOpen,openingSwitch,doorLocked;
var lP1;
var run, jump,dead, shoot,slide;

function preload(){
  bg=loadImage("bg.jpg");
  platform=loadImage("Tiles.png");
  platform1=loadImage("Tiles1.png");
  platform2=loadImage("Tiles2.png");
  doorOpen=loadImage("DoorOpen.png");
  openingSwitch=loadImage("greenSwitch.png");
  doorLocked=loadImage("DoorLocked.png");
  
  run= loadAnimation("Run1.png","Run2.png","Run3.png","Run4.png","Run5.png","Run6.png","Run7.png","Run8.png");
}

function setup() {
  createCanvas(600, 600);
  gameState="page3";
  edges=createEdgeSprites();
  movingPlatforms();
  InvisibleBoundries()
}

function draw() {
  background(bg);
  Shuffle();
  //lP1.visible=false
  if (gameState==="start"){
    background(220);
    textSize(30);
    fill("red");
    text("Robot Run",280,100);
    
    textSize(20);
    fill("blue");
    text("Press Space to start",350,450);
    if (keyDown("Space")){
      gameState="page1";
    }
  }
  
  if (gameState==="page1"){
  
    var ground=createSprite(50,550,200,10);
    ground.addImage(platform);
    ground.scale=0.2;
      
    var ground1=createSprite(300,400,200,10);
    ground1.addImage(platform1);
    ground1.scale=0.2; 
    
    var ground2=createSprite(530,250,200,10);
    ground2.addImage(platform2);
    ground2.scale=0.2; 
    
    var greenSwitch=createSprite(500,200,20,20);
    greenSwitch.addImage(openingSwitch);
    greenSwitch.scale=0.2;
    
    var closeDoor=createSprite(560,180,20,20);
    closeDoor.addImage(doorLocked);
    closeDoor.scale=0.2;
    
    
   /* if (robot.isTouching(greenSwitch)){
      closedDoor.changeAnimation(openDoor);
    }*/ 
    
   /* if (robot.isTouching(openDoor)){
      gameState="page2";
    }*/
  }
  
  if(gameState==="page2"){
    Page2();
    
  }
   if(gameState==="page3"){
    Page3();
    
  }
  
  drawSprites();  
}

function movingPlatforms(){
     lP1=createSprite(350,500,100,5);
    lP1.addImage(platform2);
    lP1.scale=0.2;
     lP1.velocityY=-4;
  lP1.visible=false;
  
  
  
     lP2=createSprite(230,100,100,5);
    lP2.addImage(platform2);
    lP2.scale=0.2;
     lP2.velocityY=4;
  lP2.visible=false;
  lP2.bounceOff(edges);
  
  lP3=createSprite(200,400,100,5);
    lP3.addImage(platform2);
    lP3.scale=0.2;
     lP3.velocityX=2;
  lP3.visible=false;
  
  
}

function InvisibleBoundries(){
  h1=createSprite(300,70,600,2);
  h2=createSprite(300,530,600,2);
  v1=createSprite(70,300,2,600);
  v2=createSprite(530,300,2,600);
    hm1=createSprite(300,220,600,2);
  hm2=createSprite(300,380,600,2);
   vm1=createSprite(220,300,2,600);
  vm2=createSprite(380,300,2,600);
}

function Shuffle(){
   lP1.bounceOff(h1);
  lP1.bounceOff(h2);
 
  lP2.bounceOff(h1);
  lP2.bounceOff(h2);
  
   lP3.bounceOff(v1);
  lP3.bounceOff(vm2);
}

function Page2(){
  var ground2=createSprite(65,250,200,10);
    ground2.addImage(platform1);
    ground2.scale=0.2; 
  
    var ground=createSprite(550,550,200,10);
    ground.addImage(platform);
    ground.scale=0.2;
  
  lP1.visible=true;
    lP2.visible=true;
        
}

function Page3(){
   var ground=createSprite(45,550,200,10);
    ground.addImage(platform1);
    ground.scale=0.2;
  
    lP3.visible=true;
  // lP1.visible=true;
  
   var ground1=createSprite(530,150,200,10);
    ground1.addImage(platform1);
    ground1.scale=0.2;
  
  var ground2=createSprite(400,250,200,10);
    ground2.addImage(platform1);
    ground2.scale=0.2;
}